<?php



$server = "localhost";
$usuario = "u366968387_phpautos";
$contra = "dom*58INTEC";
$bd ="u366968387_autos";

$conexion = mysqli_connect($server,$usuario,$contra,$bd);









?>