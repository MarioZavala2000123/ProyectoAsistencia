<?php 

$server = "localhost";
$usuario = "root";
$contra = "";
$bd="asistencia";

$conexion=mysqli_connect($server,$usuario,$contra,$bd);
   
 ?>