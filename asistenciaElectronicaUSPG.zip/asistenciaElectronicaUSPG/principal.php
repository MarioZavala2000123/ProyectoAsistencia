<!DOCTYPE html>
<html>
<head>
	<title>Administración DIGM</title>
	<link rel="stylesheet" type="text/css" href="css/menu.css">

	<meta charset="utf-8">
</head>
<body>

<div class="menuPrincipal"></div>
<div class="contenido">
	<div class="opcionesEnc"></div>

</div>

</body>
</html>